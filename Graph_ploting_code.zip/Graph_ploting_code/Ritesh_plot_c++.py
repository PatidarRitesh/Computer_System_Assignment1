import matplotlib.pyplot as plt

#For c++ integer 
n = [256,512,1024,2048,4096]
cpu = [0.116,0.949 , 16.276 ,156.646 ,1647.365]
system = [0.004, 0.009,0.012,0.040,0.225]
meatTime = [0.10611 ,0.928657 ,16.2307 ,156.571,1647.74 ] 
total_Program_ExecutionTime = [0.111531 ,0.944541,16.2819,156.761,1648.47]



plt.plot(n,cpu)
plt.legend(['CPU'])
plt.title("C++ Integer : n Vs CPU time")
plt.xlabel('n') 
plt.ylabel('CPU time') 
plt.grid()
plt.show()

plt.plot(n,system)
plt.legend(['System'])
plt.title("C++ Integer : n Vs System time")
plt.xlabel('n') 
plt.ylabel('System time') 
plt.grid()
plt.show()

plt.plot(n,meatTime)
plt.legend(['Meat time'])
plt.title("C++ Integer : n Vs Meat time")
plt.xlabel('n') 
plt.ylabel('Meat time') 
plt.grid()
plt.show()

plt.plot(n,total_Program_ExecutionTime )
plt.legend(['Total Program Execution time'])
plt.title("C++ Integer : n Vs Program execution time")
plt.xlabel('n') 
plt.ylabel('Program execution time') 
plt.grid()
plt.show()