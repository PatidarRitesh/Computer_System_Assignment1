
    

import random
import datetime
import time
import matplotlib.pyplot as plt

start1 = time.time()


n = 256
#A =[[random.randint(-50,50) for x in range(n)] for i in range(n)]
#B =[[random.randint(-50,50) for x in range(n)] for i in range(n)]
A =[[random.uniform(-100,100) for x in range(n)] for i in range(n)]
B =[[random.uniform(-100,100) for x in range(n)] for i in range(n)]
result =[[0 for _ in range(n)] for i in range(n)]

start2 = time.time()

for i in range(len(A)): 
    for j in range(len(B[0])): 
        for k in range(len(B)):
            result[i][j] += A[i][k] * B[k][j]



end2 = time.time()
end1 = time.time()
meat_time = end2 - start2
total_exetution_time = end1 - start1

try:
    proportion = meat_time * 100 / total_exetution_time
except:
    proportion = -1
print('for n =',n )
print('meat time ', meat_time)
print('total execution time ' ,total_exetution_time)
print('proportion ', proportion)


